"""Celery tasks for background processing"""
