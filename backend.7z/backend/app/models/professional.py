"""
Professional Model - REMOVED

Este modelo foi removido em favor de usar User com role='PROFESSIONAL'.
Todos os campos de profissional foram movidos para o modelo User.
"""
# NOTA: Modelo Professional removido - usar User.role = 'PROFESSIONAL'
# Campos como specialties, working_hours, commission_rate já existem em User
