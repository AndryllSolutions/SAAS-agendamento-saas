"""merge_heads

Revision ID: 7bdacd27480e
Revises: 6f2a9c1e2b0a, b1c2d3e4f5a6
Create Date: 2026-01-23 20:42:37.574727

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '7bdacd27480e'
down_revision = ('6f2a9c1e2b0a', 'b1c2d3e4f5a6')
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass

