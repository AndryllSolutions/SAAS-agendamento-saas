"""
Appointments Endpoints
"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status, Request, Query, Response

from sqlalchemy.orm import Session, joinedload
from datetime import datetime, timedelta
import secrets

from app.core.database import get_db
from app.core.security import get_current_active_user, require_professional
from app.core.config import settings
from app.core.cache import get_cache, set_cache
from app.models.appointment import Appointment, AppointmentStatus
from app.models.service import Service
from app.models.user import User, UserRole
from app.models.client import Client
from app.models.company import Company
from app.schemas.appointment import (
    AppointmentCreate,
    AppointmentUpdate,
    AppointmentResponse,
    AppointmentCancel,
    AppointmentCheckIn,
    PublicAppointmentCreate,
)
from app.services.appointment_notifications import AppointmentNotificationService
from app.services.notification_helper import NotificationHelper

router = APIRouter(
    redirect_slashes=False  # 🔥 DESATIVA REDIRECT AUTOMÁTICO - CORS FIX
)


# ========== VALIDATION HELPERS ==========

def validate_business_hours(company: Company, start_time: datetime):
    """Validate appointment is within business hours"""
    if not company.business_hours:
        return  # No restriction if business hours not configured
    
    # Get weekday name (monday, tuesday, etc.)
    weekday = start_time.strftime('%A').lower()
    hours = company.business_hours.get(weekday)
    
    if not hours or hours.get('closed'):
        weekday_pt = {
            'monday': 'segunda-feira',
            'tuesday': 'terça-feira',
            'wednesday': 'quarta-feira',
            'thursday': 'quinta-feira',
            'friday': 'sexta-feira',
            'saturday': 'sábado',
            'sunday': 'domingo'
        }.get(weekday, weekday)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Empresa fechada em {weekday_pt}"
        )
    
    # Check if time is within business hours
    start_str = start_time.strftime('%H:%M')
    if start_str < hours.get('start', '00:00') or start_str >= hours.get('end', '23:59'):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Horário fora do expediente. Funcionamento: {hours.get('start')} às {hours.get('end')}"
        )


def validate_professional_hours(professional: User, start_time: datetime):
    """Validate professional is available at requested time"""
    if not professional.working_hours:
        return  # No restriction if working hours not configured
    
    # Get weekday name
    weekday = start_time.strftime('%A').lower()
    hours = professional.working_hours.get(weekday)
    
    if not hours:
        weekday_pt = {
            'monday': 'segunda-feira',
            'tuesday': 'terça-feira',
            'wednesday': 'quarta-feira',
            'thursday': 'quinta-feira',
            'friday': 'sexta-feira',
            'saturday': 'sábado',
            'sunday': 'domingo'
        }.get(weekday, weekday)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Profissional {professional.full_name} não trabalha em {weekday_pt}"
        )
    
    # Check if time is within working hours
    start_str = start_time.strftime('%H:%M')
    if start_str < hours.get('start', '00:00') or start_str >= hours.get('end', '23:59'):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Profissional indisponível. Horários de {professional.full_name}: {hours.get('start')} às {hours.get('end')}"
        )


def apply_company_timezone(company: Company, start_time: datetime) -> datetime:
    """Apply company timezone to datetime - returns naive datetime for DB compatibility"""
    try:
        from zoneinfo import ZoneInfo
        company_tz = ZoneInfo(company.timezone or 'America/Sao_Paulo')
        
        # If datetime has timezone, convert to company timezone first
        if start_time.tzinfo is not None:
            start_time = start_time.astimezone(company_tz)
        
        # CORREÇÃO: Always return naive datetime for DB compatibility
        # Remove timezone info to avoid "can't compare offset-naive and offset-aware" errors
        return start_time.replace(tzinfo=None)
    except Exception as e:
        # Fallback: if timezone conversion fails, use naive datetime
        print(f"Warning: Timezone conversion failed: {str(e)}")
        return start_time.replace(tzinfo=None) if start_time.tzinfo else start_time


@router.post("/public", response_model=AppointmentResponse, status_code=status.HTTP_201_CREATED)
async def create_public_appointment(
    appointment_data: PublicAppointmentCreate,
    response: Response,
    request: Request,
    company_slug: str = Query(None, description="Company slug for filtering"),
    db: Session = Depends(get_db)
):
    """
    Create a new appointment without authentication (public booking)
    Supports filtering by company slug
    """
    # Get company by slug or default to first company
    if company_slug:
        company = db.query(Company).filter(Company.slug == company_slug).first()
        if not company:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Empresa não encontrada"
            )
    else:
        # Fallback to first company for backward compatibility
        company = db.query(Company).first()
        if not company:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Nenhuma empresa encontrada"
            )
    
    # Get service
    service = db.query(Service).filter(
        Service.id == appointment_data.service_id,
        Service.company_id == company.id
    ).first()
    
    if not service:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Serviço não encontrado"
        )
    
    # Get professional (optional - can be None for "no preference")
    professional = None
    if appointment_data.professional_id:
        professional = db.query(User).filter(
            User.id == appointment_data.professional_id,
            User.company_id == company.id,
            User.role.in_([UserRole.PROFESSIONAL, UserRole.OWNER, UserRole.MANAGER])
        ).first()
        
        if not professional:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Profissional não encontrado"
            )
    
    # CORREÇÃO: Apply company timezone
    start_time_local = apply_company_timezone(company, appointment_data.start_time)
    
    # CORREÇÃO: Validate business hours
    validate_business_hours(company, start_time_local)
    
    # CORREÇÃO: Validate professional hours (only if professional is selected)
    if professional:
        validate_professional_hours(professional, start_time_local)
    
    # Calculate end time
    end_time = start_time_local + timedelta(minutes=service.duration_minutes)
    
    # Create or get client
    client = None
    if appointment_data.client_email or appointment_data.client_phone:
        # Try to find existing client
        client = db.query(Client).filter(
            Client.company_id == company.id,
            (Client.email == appointment_data.client_email) | (Client.phone == appointment_data.client_phone)
        ).first()
        
        if not client:
            # Create new client
            client = Client(
                company_id=company.id,
                full_name=appointment_data.client_name,
                email=appointment_data.client_email,
                phone=appointment_data.client_phone
            )
            db.add(client)
            db.commit()
            db.refresh(client)
    
    existing_appointment = db.query(Appointment).filter(
        Appointment.company_id == company.id,
        Appointment.professional_id == appointment_data.professional_id,
        Appointment.service_id == appointment_data.service_id,
        Appointment.start_time == start_time_local,
        Appointment.end_time == end_time,
        Appointment.client_crm_id == (client.id if client else None),
        Appointment.client_notes == appointment_data.client_notes,
        Appointment.status.in_([
            AppointmentStatus.PENDING,
            AppointmentStatus.CONFIRMED,
            AppointmentStatus.CHECKED_IN,
            AppointmentStatus.IN_PROGRESS
        ])
    ).first()

    if existing_appointment:
        response.status_code = status.HTTP_200_OK
        return AppointmentResponse.model_validate(existing_appointment)
    
    # CORREÇÃO: Check for conflicts (only if professional is selected)
    if professional:
        conflicts = db.query(Appointment).filter(
            Appointment.company_id == company.id,
            Appointment.professional_id == appointment_data.professional_id,
            Appointment.status.in_([
                AppointmentStatus.PENDING,
                AppointmentStatus.CONFIRMED,
                AppointmentStatus.CHECKED_IN,
                AppointmentStatus.IN_PROGRESS
            ]),
            Appointment.start_time < end_time,
            Appointment.end_time > start_time_local
        ).first()
        
        if conflicts:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Horário não disponível. Profissional já possui compromisso neste horário."
            )
    
    # Generate check-in code
    check_in_code = secrets.token_urlsafe(8)
    
    # Create appointment
    appointment = Appointment(
        company_id=company.id,
        client_crm_id=client.id if client else None,
        professional_id=appointment_data.professional_id,
        service_id=appointment_data.service_id,
        start_time=start_time_local,
        end_time=end_time,
        client_notes=appointment_data.client_notes,
        check_in_code=check_in_code,
        status=AppointmentStatus.PENDING
    )
    
    db.add(appointment)
    db.commit()
    db.refresh(appointment)
    
    # Send notifications
    try:
        AppointmentNotificationService.send_booking_confirmation(
            db=db,
            client_name=appointment_data.client_name,
            client_email=appointment_data.client_email,
            client_phone=appointment_data.client_phone,
            professional_name=professional.full_name if professional else "",
            service_name=service.name,
            start_time=appointment_data.start_time,
            company_name=company.name,
            company_id=company.id,
            check_in_code=check_in_code,
            user_id=client.user_id if client and client.user_id else None
        )
    except Exception as e:
        # Log error but don't fail the booking
        print(f"Error sending notification: {e}")
        import traceback
        traceback.print_exc()
    
    return AppointmentResponse.model_validate(appointment)


@router.post("", response_model=AppointmentResponse, status_code=status.HTTP_201_CREATED)
@router.post("/", response_model=AppointmentResponse, status_code=status.HTTP_201_CREATED, include_in_schema=False)
async def create_appointment(
    appointment_data: AppointmentCreate,
    response: Response,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Create a new appointment
    """
    # Get company
    company = db.query(Company).filter(
        Company.id == current_user.company_id
    ).first()
    
    if not company:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Empresa não encontrada"
        )
    
    # Get service to calculate end time
    service = db.query(Service).filter(
        Service.id == appointment_data.service_id,
        Service.company_id == current_user.company_id
    ).first()
    
    if not service:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Serviço não encontrado"
        )
    
    # Get professional
    professional = db.query(User).filter(
        User.id == appointment_data.professional_id,
        User.company_id == current_user.company_id
    ).first()
    
    if not professional:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Profissional não encontrado"
        )
    
    # CORREÇÃO: Apply company timezone
    start_time_local = apply_company_timezone(company, appointment_data.start_time)
    
    # CORREÇÃO: Validate business hours
    validate_business_hours(company, start_time_local)
    
    # CORREÇÃO: Validate professional hours
    validate_professional_hours(professional, start_time_local)
    
    # Calculate end time
    end_time = start_time_local + timedelta(minutes=service.duration_minutes)
    
    existing_appointment = db.query(Appointment).filter(
        Appointment.company_id == current_user.company_id,
        Appointment.professional_id == appointment_data.professional_id,
        Appointment.service_id == appointment_data.service_id,
        Appointment.resource_id == appointment_data.resource_id,
        Appointment.start_time == start_time_local,
        Appointment.end_time == end_time,
        Appointment.client_crm_id == (appointment_data.client_id or None),
        Appointment.client_notes == appointment_data.client_notes,
        Appointment.status.in_([
            AppointmentStatus.PENDING,
            AppointmentStatus.CONFIRMED,
            AppointmentStatus.CHECKED_IN,
            AppointmentStatus.IN_PROGRESS
        ])
    ).first()

    if existing_appointment:
        response.status_code = status.HTTP_200_OK
        return AppointmentResponse.model_validate(existing_appointment)
    
    # CORREÇÃO: Check for conflicts (including CHECKED_IN and IN_PROGRESS)
    conflicts = db.query(Appointment).filter(
        Appointment.company_id == current_user.company_id,
        Appointment.professional_id == appointment_data.professional_id,
        Appointment.status.in_([
            AppointmentStatus.PENDING,
            AppointmentStatus.CONFIRMED,
            AppointmentStatus.CHECKED_IN,
            AppointmentStatus.IN_PROGRESS
        ]),
        Appointment.start_time < end_time,
        Appointment.end_time > start_time_local
    ).first()
    
    if conflicts:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Horário não disponível. Profissional já possui compromisso neste horário."
        )
    
    # Set client_id
    client_crm_id = appointment_data.client_id or None
    
    # Generate check-in code
    check_in_code = secrets.token_urlsafe(8)
    
    # Create appointment
    appointment = Appointment(
        company_id=current_user.company_id,
        client_crm_id=client_crm_id,
        professional_id=appointment_data.professional_id,
        service_id=appointment_data.service_id,
        resource_id=appointment_data.resource_id,
        start_time=start_time_local,
        end_time=end_time,
        client_notes=appointment_data.client_notes,
        check_in_code=check_in_code,
    )
    
    db.add(appointment)
    db.commit()
    db.refresh(appointment)
    
    # Enviar notificações de confirmação
    try:
        # Verificar se deve enviar notificacao de novo agendamento
        if NotificationHelper.should_send_notification(db, current_user.company_id, 'new_appointment'):
            # Buscar dados do cliente
            client = None
            if client_crm_id:
                client = db.query(Client).filter(Client.id == client_crm_id).first()
            
            if client and client.email:
                AppointmentNotificationService.send_booking_confirmation(
                    db=db,
                    client_name=client.full_name,
                    client_email=client.email,
                    client_phone=client.phone or client.cellphone,
                    service_name=service.name,
                    professional_name=professional.full_name,
                    start_time=start_time_local,
                    company_name=company.name,
                    company_id=company.id,
                    check_in_code=check_in_code,
                    user_id=client.user_id
                )
    except Exception as e:
        print(f"Erro ao enviar notificações: {e}")
        import traceback
        traceback.print_exc()
        # Não falhar o agendamento se notificação falhar
    
    return appointment


@router.get("/", response_model=List[AppointmentResponse])
@router.get("", response_model=List[AppointmentResponse])  # 🔥 Rota explicita sem slash - CORS fix
async def list_appointments(
    status_filter: str = None,
    professional_id: int = None,
    client_id: int = None,
    start_date: datetime = None,
    end_date: datetime = None,
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    List appointments (Cached for 1 minute)
    """
    from app.core.tenant_context import set_tenant_context
    
    # Set tenant context for RLS
    if current_user.company_id:
        set_tenant_context(db, current_user.company_id)
    
    # Cache key - include all filters for proper cache invalidation
    cache_key = f"appointments:list:{current_user.company_id}:{status_filter}:{professional_id}:{client_id}:{start_date}:{end_date}:{skip}:{limit}"
    
    # Try to get from cache first
    cached = await get_cache(cache_key)
    if cached:
        return cached
    
    # OTIMIZAÇÃO: Eager loading para evitar N+1 queries
    query = db.query(Appointment).options(
        joinedload(Appointment.client_crm),
        joinedload(Appointment.professional),
        joinedload(Appointment.service),
        joinedload(Appointment.resource)
    ).filter(Appointment.company_id == current_user.company_id)
    
    # Filter by user role
    # ✅ CORREÇÃO: OWNER e MANAGER veem TODOS os agendamentos da empresa
    if current_user.role == UserRole.PROFESSIONAL:
        query = query.filter(Appointment.professional_id == current_user.id)
    elif current_user.role == UserRole.CLIENT:
        # Para clientes, buscar pelo client_crm_id através do Client.user_id
        from app.models.client import Client
        client = db.query(Client).filter(Client.user_id == current_user.id).first()
        if client:
            query = query.filter(Appointment.client_crm_id == client.id)
        else:
            # Se não tem Client associado, retornar vazio
            query = query.filter(Appointment.id == -1)
    # OWNER e MANAGER não têm filtro adicional - veem todos os agendamentos da empresa
    
    # Apply filters
    if status_filter:
        query = query.filter(Appointment.status == status_filter)
    
    if professional_id:
        query = query.filter(Appointment.professional_id == professional_id)
    
    if client_id:
        query = query.filter(Appointment.client_crm_id == client_id)
    
    if start_date:
        query = query.filter(Appointment.start_time >= start_date)
    
    if end_date:
        query = query.filter(Appointment.start_time <= end_date)
    
    appointments = query.order_by(Appointment.start_time.desc()).offset(skip).limit(limit).all()
    
    # Convert to Pydantic models for caching
    appointments_response = [AppointmentResponse.model_validate(apt) for apt in appointments]
    
    # Cache result for 1 minute (60 seconds)
    await set_cache(cache_key, appointments_response, ttl=60)
    
    return appointments_response


@router.get("/{appointment_id}", response_model=AppointmentResponse)
async def get_appointment(
    appointment_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Get appointment by ID
    """
    appointment = db.query(Appointment).filter(
        Appointment.id == appointment_id,
        Appointment.company_id == current_user.company_id
    ).first()
    
    if not appointment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Agendamento não encontrado"
        )
    
    # Check permissions
    if current_user.role == UserRole.CLIENT:
        from app.models.client import Client
        client = db.query(Client).filter(Client.user_id == current_user.id).first()
        if not client or appointment.client_crm_id != client.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Sem permissão para acessar este agendamento"
            )
    
    if current_user.role == UserRole.PROFESSIONAL and appointment.professional_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Sem permissão para acessar este agendamento"
        )
    
    return appointment


@router.put("/{appointment_id}", response_model=AppointmentResponse)
async def update_appointment(
    appointment_id: int,
    appointment_data: AppointmentUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Update appointment
    """
    appointment = db.query(Appointment).filter(
        Appointment.id == appointment_id,
        Appointment.company_id == current_user.company_id
    ).first()
    
    if not appointment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Agendamento não encontrado"
        )
    
    # Check permissions
    if current_user.role == "client":
        from app.models.client import Client
        client = db.query(Client).filter(Client.user_id == current_user.id).first()
        if not client or appointment.client_crm_id != client.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Sem permissão para atualizar este agendamento"
            )
    
    update_data = appointment_data.dict(exclude_unset=True)
    
    # Recalculate end_time if start_time changed
    if "start_time" in update_data:
        service = db.query(Service).filter(Service.id == appointment.service_id).first()
        update_data["end_time"] = update_data["start_time"] + timedelta(minutes=service.duration_minutes)
    
    for field, value in update_data.items():
        setattr(appointment, field, value)
    
    db.commit()
    db.refresh(appointment)
    
    return appointment


@router.post("/{appointment_id}/cancel", response_model=AppointmentResponse)
async def cancel_appointment(
    appointment_id: int,
    cancel_data: AppointmentCancel,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Cancel appointment
    """
    appointment = db.query(Appointment).filter(
        Appointment.id == appointment_id,
        Appointment.company_id == current_user.company_id
    ).first()
    
    if not appointment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Agendamento não encontrado"
        )
    
    # Check cancellation deadline
    hours_until_appointment = (appointment.start_time - datetime.utcnow()).total_seconds() / 3600
    
    if hours_until_appointment < settings.CANCELLATION_DEADLINE_HOURS and current_user.role == "client":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Cancelamento deve ser feito com pelo menos {settings.CANCELLATION_DEADLINE_HOURS} horas de antecedência"
        )
    
    appointment.status = AppointmentStatus.CANCELLED
    appointment.cancelled_at = datetime.utcnow()
    appointment.cancelled_by = current_user.id
    appointment.cancellation_reason = cancel_data.cancellation_reason
    
    db.commit()
    db.refresh(appointment)
    
    # TODO: Notify waitlist
    
    return appointment


@router.post("/{appointment_id}/check-in", response_model=AppointmentResponse)
async def check_in_appointment(
    appointment_id: int,
    check_in_data: AppointmentCheckIn,
    current_user: User = Depends(require_professional),
    db: Session = Depends(get_db)
):
    """
    Check-in appointment with QR code (Professional only)
    """
    appointment = db.query(Appointment).filter(
        Appointment.id == appointment_id,
        Appointment.company_id == current_user.company_id,
        Appointment.check_in_code == check_in_data.check_in_code
    ).first()
    
    if not appointment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Agendamento não encontrado ou código inválido"
        )
    
    appointment.status = AppointmentStatus.CHECKED_IN
    appointment.checked_in_at = datetime.utcnow()
    
    db.commit()
    db.refresh(appointment)
    
    return appointment


@router.post("/{appointment_id}/confirm", response_model=AppointmentResponse)
async def confirm_appointment(
    appointment_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Confirm appointment (change status from PENDING to CONFIRMED)
    """
    appointment = db.query(Appointment).filter(
        Appointment.id == appointment_id,
        Appointment.company_id == current_user.company_id
    ).first()
    
    if not appointment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Agendamento não encontrado"
        )
    
    # Check permissions
    if current_user.role == UserRole.PROFESSIONAL and appointment.professional_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Sem permissão para confirmar este agendamento"
        )
    
    # Only allow confirmation if appointment is PENDING
    if appointment.status != AppointmentStatus.PENDING:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Não é possível confirmar agendamento com status {appointment.status}"
        )
    
    appointment.status = AppointmentStatus.CONFIRMED
    
    db.commit()
    db.refresh(appointment)
    
    # Send confirmation notification
    try:
        if appointment.client_crm:
            client = appointment.client_crm
            company = db.query(Company).filter(Company.id == current_user.company_id).first()
            
            AppointmentNotificationService.send_booking_confirmation(
                db=db,
                client_name=client.full_name,
                client_email=client.email,
                client_phone=client.phone or client.cellphone,
                professional_name=appointment.professional.full_name,
                service_name=appointment.service.name,
                start_time=appointment.start_time,
                company_name=company.name,
                company_id=company.id,
                check_in_code=appointment.check_in_code,
                user_id=client.user_id
            )
    except Exception as e:
        print(f"Erro ao enviar notificação de confirmação: {e}")
    
    return appointment


@router.post("/{appointment_id}/reschedule", response_model=AppointmentResponse)
async def reschedule_appointment(
    appointment_id: int,
    new_start_time: datetime,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Reschedule appointment to a new time
    """
    appointment = db.query(Appointment).filter(
        Appointment.id == appointment_id,
        Appointment.company_id == current_user.company_id
    ).first()
    
    if not appointment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Agendamento não encontrado"
        )
    
    # Check permissions
    if current_user.role == UserRole.PROFESSIONAL and appointment.professional_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Sem permissão para reagendar este agendamento"
        )
    
    # Cannot reschedule cancelled or completed appointments
    if appointment.status in [AppointmentStatus.CANCELLED, AppointmentStatus.COMPLETED]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Não é possível reagendar agendamento com status {appointment.status}"
        )
    
    # Get company for timezone
    company = db.query(Company).filter(Company.id == current_user.company_id).first()
    
    # Apply company timezone
    new_start_time_local = apply_company_timezone(company, new_start_time)
    
    # Validate business hours
    validate_business_hours(company, new_start_time_local)
    
    # Validate professional hours
    professional = db.query(User).filter(User.id == appointment.professional_id).first()
    validate_professional_hours(professional, new_start_time_local)
    
    # Get service to calculate new end time
    service = db.query(Service).filter(Service.id == appointment.service_id).first()
    new_end_time = new_start_time_local + timedelta(minutes=service.duration_minutes)
    
    # Check for conflicts (excluding current appointment)
    conflicts = db.query(Appointment).filter(
        Appointment.company_id == current_user.company_id,
        Appointment.professional_id == appointment.professional_id,
        Appointment.id != appointment_id,  # Exclude current appointment
        Appointment.status.in_([
            AppointmentStatus.PENDING,
            AppointmentStatus.CONFIRMED,
            AppointmentStatus.CHECKED_IN,
            AppointmentStatus.IN_PROGRESS
        ]),
        Appointment.start_time < new_end_time,
        Appointment.end_time > new_start_time_local
    ).first()
    
    if conflicts:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Horário não disponível. Profissional já possui compromisso neste horário."
        )
    
    # Update appointment times
    old_start_time = appointment.start_time
    appointment.start_time = new_start_time_local
    appointment.end_time = new_end_time
    
    # Reset status to PENDING if it was CONFIRMED
    if appointment.status == AppointmentStatus.CONFIRMED:
        appointment.status = AppointmentStatus.PENDING
    
    db.commit()
    db.refresh(appointment)
    
    # Send rescheduling notification
    try:
        if appointment.client_crm:
            client = appointment.client_crm
            
            AppointmentNotificationService.send_booking_confirmation(
                db=db,
                client_name=client.full_name,
                client_email=client.email,
                client_phone=client.phone or client.cellphone,
                professional_name=professional.full_name,
                service_name=service.name,
                start_time=new_start_time_local,
                company_name=company.name,
                company_id=company.id,
                check_in_code=appointment.check_in_code,
                user_id=client.user_id
            )
    except Exception as e:
        print(f"Erro ao enviar notificação de reagendamento: {e}")
    
    return appointment


@router.get("/calendar", response_model=List[AppointmentResponse])
async def get_appointments_calendar(
    start_date: datetime,
    end_date: datetime,
    professional_id: int = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Get appointments for calendar view (filtered by date range)
    Optimized for calendar rendering with date range filtering
    """
    query = db.query(Appointment).options(
        joinedload(Appointment.client_crm),
        joinedload(Appointment.professional),
        joinedload(Appointment.service),
        joinedload(Appointment.resource)
    ).filter(
        Appointment.company_id == current_user.company_id,
        Appointment.start_time >= start_date,
        Appointment.start_time <= end_date,
        Appointment.status.in_([
            AppointmentStatus.PENDING,
            AppointmentStatus.CONFIRMED,
            AppointmentStatus.CHECKED_IN,
            AppointmentStatus.IN_PROGRESS
        ])
    )
    
    # Filter by user role
    if current_user.role == UserRole.PROFESSIONAL:
        query = query.filter(Appointment.professional_id == current_user.id)
    elif current_user.role == UserRole.CLIENT:
        from app.models.client import Client
        client = db.query(Client).filter(Client.user_id == current_user.id).first()
        if client:
            query = query.filter(Appointment.client_crm_id == client.id)
        else:
            query = query.filter(Appointment.id == -1)
    
    # Filter by professional if specified
    if professional_id:
        query = query.filter(Appointment.professional_id == professional_id)
    
    appointments = query.order_by(Appointment.start_time).all()
    
    return [AppointmentResponse.model_validate(apt) for apt in appointments]


@router.get("/conflicts", response_model=dict)
async def check_appointment_conflicts(
    professional_id: int,
    start_time: datetime,
    duration_minutes: int = 60,
    exclude_appointment_id: int = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Check if there are any conflicts for a given time slot
    Useful for real-time validation before creating/updating appointments
    """
    # Get company for timezone
    company = db.query(Company).filter(Company.id == current_user.company_id).first()
    
    # Apply company timezone
    start_time_local = apply_company_timezone(company, start_time)
    end_time_local = start_time_local + timedelta(minutes=duration_minutes)
    
    # Get professional
    professional = db.query(User).filter(
        User.id == professional_id,
        User.company_id == current_user.company_id
    ).first()
    
    if not professional:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Profissional não encontrado"
        )
    
    # Check business hours
    try:
        validate_business_hours(company, start_time_local)
    except HTTPException as e:
        return {
            "has_conflict": True,
            "conflict_type": "business_hours",
            "message": e.detail
        }
    
    # Check professional hours
    try:
        validate_professional_hours(professional, start_time_local)
    except HTTPException as e:
        return {
            "has_conflict": True,
            "conflict_type": "professional_hours",
            "message": e.detail
        }
    
    # Check for appointment conflicts
    query = db.query(Appointment).filter(
        Appointment.company_id == current_user.company_id,
        Appointment.professional_id == professional_id,
        Appointment.status.in_([
            AppointmentStatus.PENDING,
            AppointmentStatus.CONFIRMED,
            AppointmentStatus.CHECKED_IN,
            AppointmentStatus.IN_PROGRESS
        ]),
        Appointment.start_time < end_time_local,
        Appointment.end_time > start_time_local
    )
    
    # Exclude specific appointment (useful for rescheduling)
    if exclude_appointment_id:
        query = query.filter(Appointment.id != exclude_appointment_id)
    
    conflicts = query.all()
    
    if conflicts:
        conflict_details = []
        for apt in conflicts:
            conflict_details.append({
                "id": apt.id,
                "start_time": apt.start_time.isoformat(),
                "end_time": apt.end_time.isoformat(),
                "service_name": apt.service.name if apt.service else None,
                "client_name": apt.client_crm.full_name if apt.client_crm else None
            })
        
        return {
            "has_conflict": True,
            "conflict_type": "appointment",
            "message": "Profissional já possui compromisso neste horário",
            "conflicts": conflict_details
        }
    
    return {
        "has_conflict": False,
        "message": "Horário disponível"
    }