export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

interface CountryFAQ {
  country: string;
  currency: string;
  faqs: FAQItem[];
}

const faqData: Record<string, CountryFAQ> = {
  br: {
    country: "Brasil",
    currency: "BRL",
    faqs: [
      { id: "br-1", question: "Como funciona o período de teste?", answer: "Você tem 14 dias gratuitos para testar todas as funcionalidades do ATENDO. Não é necessário cartão de crédito.", category: "geral" },
      { id: "br-2", question: "Posso cancelar a qualquer momento?", answer: "Sim! Você pode cancelar sua assinatura a qualquer momento, sem multas ou taxas adicionais.", category: "geral" },
      { id: "br-3", question: "O ATENDO emite nota fiscal?", answer: "Sim, emitimos nota fiscal de serviço (NFS-e) automaticamente para todos os planos.", category: "impostos" },
      { id: "br-4", question: "Como funciona o suporte técnico?", answer: "Oferecemos suporte via chat, email e WhatsApp em horário comercial. Planos premium têm suporte prioritário 24/7.", category: "suporte" },
      { id: "br-5", question: "Os dados estão seguros?", answer: "Sim! Utilizamos criptografia de ponta a ponta, servidores seguros e estamos em conformidade com a LGPD.", category: "conformidade" },
      { id: "br-6", question: "Integra com WhatsApp?", answer: "Sim! Temos integração nativa com WhatsApp Business API para envio de mensagens, lembretes e confirmações automáticas.", category: "integracao" },
      { id: "br-7", question: "Como funciona o agendamento online?", answer: "Seus clientes podem agendar diretamente pelo link personalizado, escolhendo profissional, serviço, data e horário disponíveis.", category: "geral" },
      { id: "br-8", question: "Preciso de CNPJ para usar?", answer: "Não é obrigatório. Profissionais autônomos com CPF também podem utilizar o sistema normalmente.", category: "impostos" },
      { id: "br-9", question: "Posso personalizar com minha marca?", answer: "Sim! Você pode adicionar seu logo, cores e domínio personalizado em todos os planos.", category: "geral" },
      { id: "br-10", question: "Integra com Google Calendar?", answer: "Sim! A sincronização com Google Calendar é bidirecional e automática.", category: "integracao" },
    ],
  },
  ar: {
    country: "Argentina",
    currency: "ARS",
    faqs: [
      { id: "ar-1", question: "¿Cómo funciona el período de prueba?", answer: "Tienes 14 días gratuitos para probar todas las funcionalidades de ATENDO. No se requiere tarjeta de crédito.", category: "geral" },
      { id: "ar-2", question: "¿Puedo cancelar en cualquier momento?", answer: "¡Sí! Puedes cancelar tu suscripción en cualquier momento, sin multas ni cargos adicionales.", category: "geral" },
      { id: "ar-3", question: "¿ATENDO emite factura?", answer: "Sí, emitimos factura electrónica automáticamente para todos los planes.", category: "impostos" },
      { id: "ar-4", question: "¿Cómo funciona el soporte técnico?", answer: "Ofrecemos soporte por chat, email y WhatsApp en horario comercial.", category: "suporte" },
      { id: "ar-5", question: "¿Los datos están seguros?", answer: "¡Sí! Utilizamos encriptación de punta a punta y servidores seguros.", category: "conformidade" },
      { id: "ar-6", question: "¿Se integra con WhatsApp?", answer: "¡Sí! Tenemos integración nativa con WhatsApp Business API.", category: "integracao" },
    ],
  },
};

export function getFAQByCountry(countryCode: string): CountryFAQ {
  return faqData[countryCode] || faqData["br"];
}

export function getAllFAQCategories(): string[] {
  return ["geral", "impostos", "suporte", "conformidade", "integracao"];
}
