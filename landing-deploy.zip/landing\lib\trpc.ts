// Mock tRPC client for landing page
// This avoids dependencies on the full tRPC setup

const createMockQuery = () => ({
  useQuery: () => ({ data: null, isLoading: false, error: null }),
  useMutation: (opts?: any) => ({
    mutate: () => {},
    mutateAsync: async () => {},
    isLoading: false,
    error: null,
  }),
});

const createProxy = (): any => {
  return new Proxy({}, {
    get: (_target, _prop) => {
      return new Proxy({}, {
        get: (_t, _p) => {
          return {
            useQuery: () => ({ data: null, isLoading: false, error: null }),
            useMutation: (opts?: any) => ({
              mutate: () => {},
              mutateAsync: async () => {},
              isLoading: false,
              error: null,
            }),
          };
        }
      });
    }
  });
};

export const trpc = createProxy();
