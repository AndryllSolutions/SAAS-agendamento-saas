"""
Agendamento SaaS - Sistema de Agendamento Online
"""

__version__ = "1.0.0"
