"""Pydantic schemas for request/response validation"""
