"""Core module for configuration and utilities"""
